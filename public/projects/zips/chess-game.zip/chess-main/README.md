# Minimax Chess

A browser-based chess game where you play as White against an AI opponent powered by the **Minimax algorithm with Alpha-Beta pruning**. No external chess libraries — the engine is written from scratch in vanilla JavaScript.

![Project Demo](./project-demo.png)

---

## Features

- Play as **White** against an AI opponent (**Black**)
- Full chess rule support:
  - All standard piece movements
  - Castling (kingside & queenside)
  - En passant
  - Pawn promotion (auto-promotes to Queen)
  - Check, checkmate, and stalemate detection
- Valid move highlighting on piece selection
- Game status panel (current turn, game state)
- Instant restart button

---

## How the AI Works

The AI uses the classic **Minimax algorithm** with **Alpha-Beta pruning** at depth 3.

### Minimax

Minimax is a recursive decision-making algorithm used in two-player zero-sum games. It builds a game tree by simulating all possible moves up to a given depth:

- **Maximizing player (White)** — tries to maximize the board score
- **Minimizing player (Black / AI)** — tries to minimize the board score

At each leaf node (depth 0 or terminal state), the board is evaluated using a **material score**:

| Piece  | Value |
|--------|-------|
| Pawn   | 10    |
| Knight | 30    |
| Bishop | 30    |
| Rook   | 50    |
| Queen  | 90    |
| King   | 900   |

White pieces add to the score, Black pieces subtract from it. The AI picks the move that leads to the lowest score (best for Black).

### Alpha-Beta Pruning

Alpha-Beta pruning is an optimization on top of Minimax. It cuts off branches in the search tree that cannot possibly affect the final decision, significantly reducing the number of nodes evaluated without changing the result.

- **Alpha** — best score the maximizing player can guarantee
- **Beta** — best score the minimizing player can guarantee
- If `beta <= alpha`, the branch is pruned (skipped)

At depth 3, the AI evaluates thousands of positions per move while remaining fast enough for real-time play in the browser.

---

## Tech Stack

- **React 19** — UI and state management
- **Vite 8** — build tool and dev server
- **Tailwind CSS** — styling via utility classes
- **Vanilla JS** — chess engine and AI (no external chess libraries)

---

## Project Structure

```
src/
├── engine/
│   ├── Game.js        # Board state, move generation, legal move validation
│   └── AI.js          # Minimax + Alpha-Beta pruning
├── components/
│   ├── ChessBoard.jsx  # Board rendering, piece selection, move handling
│   └── PieceSVGs.js    # SVG piece definitions
└── App.jsx             # Game loop, status display, restart logic
```

### Key files

**`Game.js`** — the core chess engine:
- Maintains board state, turn, castling rights, and en passant target
- `getPseudoLegalMoves()` — generates all moves for a piece ignoring king safety
- `getLegalMovesForPiece()` — filters pseudo-legal moves by simulating each and checking if the king is left in check
- `makeMove()` — executes a move, handles special cases (castling, en passant, promotion), updates game state
- `clone()` — deep-clones the game state for AI tree simulation

**`AI.js`** — the AI engine:
- `minimax()` — recursive Minimax with Alpha-Beta pruning
- `getBestMove()` — entry point, returns the best move for the current player at depth 3

**`ChessBoard.jsx`** — the board UI:
- Renders the 8×8 board with pieces as inline SVGs
- Handles click events for piece selection and move execution
- Highlights valid destination squares
- Triggers AI move after each player move via `useEffect`

---

## Getting Started

**Prerequisites:** Node.js 18+

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

---
##To live preview [https://weather-five-chi-39.vercel.app/](https://weather-five-chi-39.vercel.app/)
## Gameplay

1. Click a white piece to select it — valid moves highlight on the board
2. Click a highlighted square to move your piece
3. The AI automatically responds with its move
4. The game ends on **checkmate** or **stalemate** — click **Restart Game** to play again
