import React, { useRef, useEffect, useState } from 'react';
import { Game, Color } from '../engine/Game';
import { getBestMove } from '../engine/AI';
import { PieceSVGs } from './PieceSVGs';

const SQUARE_SIZE = 80;
const BOARD_SIZE = SQUARE_SIZE * 8;

export default function ChessBoard({ game, setGame, onGameOver }) {
  const canvasRef = useRef(null);
  const [selectedSquare, setSelectedSquare] = useState(null);
  const [legalMoves, setLegalMoves] = useState([]);
  
  // Animation state (tracks piece currently flying)
  const [animatingMove, setAnimatingMove] = useState(null);
  
  // Need to store cached images
  const images = useRef({});
  const [imagesLoaded, setImagesLoaded] = useState(false);

  // Initialize images from SVG strings
  useEffect(() => {
    let loadedCount = 0;
    const totalImages = 12;
    
    for (const color in PieceSVGs) {
      for (const piece in PieceSVGs[color]) {
        const svgString = PieceSVGs[color][piece];
        const blob = new Blob([svgString], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        const img = new Image();
        img.onload = () => {
          loadedCount++;
          if (loadedCount === totalImages) {
            setImagesLoaded(true);
          }
        };
        img.src = url;
        if (!images.current[color]) images.current[color] = {};
        images.current[color][piece] = img;
      }
    }
  }, []);

  // Main render loop
  useEffect(() => {
    if (!imagesLoaded) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationFrameId;

    const render = () => {
      // 1. Draw Board Grid
      for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
          const isLight = (x + y) % 2 === 0;
          ctx.fillStyle = isLight ? '#f0d9b5' : '#b58863';
          ctx.fillRect(x * SQUARE_SIZE, y * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
        }
      }

      // 2. Highlight selected square
      if (selectedSquare) {
        ctx.fillStyle = 'rgba(255, 255, 0, 0.4)';
        ctx.fillRect(selectedSquare.x * SQUARE_SIZE, selectedSquare.y * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
      }

      // 3. Highlight legal moves
      for (const move of legalMoves) {
        ctx.beginPath();
        const centerX = move.endX * SQUARE_SIZE + SQUARE_SIZE / 2;
        const centerY = move.endY * SQUARE_SIZE + SQUARE_SIZE / 2;
        ctx.arc(centerX, centerY, SQUARE_SIZE / 6, 0, 2 * Math.PI);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
        ctx.fill();
      }

      // 4. Draw Pieces
      for (let y = 0; y < 8; y++) {
        for (let x = 0; x < 8; x++) {
          const piece = game.board[y][x];
          
          // If this piece is currently animating from/to somewhere, skip drawing it in its final destination
          if (animatingMove && animatingMove.endX === x && animatingMove.endY === y) {
             continue; 
          }
          
          if (piece) {
             const img = images.current[piece.color][piece.type];
             if (img) {
                // If it's the moving piece, draw it at interpolated position
                if (animatingMove && animatingMove.piece === piece && animatingMove.endX === x && animatingMove.endY === y) {
                  // Actually, it's easier to skip drawing here and draw the flying piece at the end
                } else {
                  ctx.drawImage(img, x * SQUARE_SIZE, y * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
                }
             }
          }
        }
      }

      // 5. Draw Animating piece
      if (animatingMove) {
        const { startX, startY, endX, endY, progress, piece } = animatingMove;
        const currentX = startX + (endX - startX) * progress;
        const currentY = startY + (endY - startY) * progress;
        
        const img = images.current[piece.color][piece.type];
        if (img) {
          ctx.drawImage(img, currentX * SQUARE_SIZE, currentY * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
        }
      }

      // Keep looping if animating
      if (animatingMove) {
        animationFrameId = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
    };
  }, [game, selectedSquare, legalMoves, animatingMove, imagesLoaded]);

  // Handle Animation progression
  useEffect(() => {
    if (!animatingMove) return;

    let startTime = null;
    const duration = 200; // ms

    const step = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      
      setAnimatingMove(prev => ({ ...prev, progress }));

      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        // Animation done
        setAnimatingMove(null);
        
        // Let React state update game naturally if we need to?
        // Game has already been mutated, and `game` prop changes when parent re-renders
      }
    };

    requestAnimationFrame(step);
  }, [animatingMove?.id]); // Use a unique ID so it triggers properly

  const handleAIMove = async (currentGame) => {
    // Slight delay to make AI feel natural
    setTimeout(() => {
      if (currentGame.status !== 'active') return;
      
      const bestMove = getBestMove(currentGame, 3); // Depth 3
      if (bestMove) {
         const piece = currentGame.board[bestMove.startY][bestMove.startX];
         
         const newGame = currentGame.clone();
         newGame.makeMove(bestMove.startX, bestMove.startY, bestMove.endX, bestMove.endY);
         
         // Trigger animation
         setAnimatingMove({
           id: Date.now(),
           startX: bestMove.startX,
           startY: bestMove.startY,
           endX: bestMove.endX,
           endY: bestMove.endY,
           progress: 0,
           piece: piece
         });

         setTimeout(() => {
           setGame(newGame);
           if (newGame.status !== 'active') {
             onGameOver(newGame.status);
           }
         }, 250); // commit state after animation duration
      } else {
        // No moves for AI
        onGameOver(currentGame.status);
      }
    }, 100);
  };

  const handleCanvasClick = (e) => {
    if (game.status !== 'active' || game.turn === Color.BLACK) return; // Wait for AI
    if (animatingMove) return; // Prevent clicks while animating

    const rect = canvasRef.current.getBoundingClientRect();
    const x = Math.floor((e.clientX - rect.left) / (rect.width / 8));
    const y = Math.floor((e.clientY - rect.top) / (rect.height / 8));

    if (x < 0 || x > 7 || y < 0 || y > 7) return;

    if (selectedSquare) {
      // Check if clicking a legal move
      const targetMove = legalMoves.find(m => m.endX === x && m.endY === y);
      if (targetMove) {
        const piece = game.board[selectedSquare.y][selectedSquare.x];
        
        // Apply move
        const newGame = game.clone();
        newGame.makeMove(selectedSquare.x, selectedSquare.y, x, y);
        
        setAnimatingMove({
           id: Date.now(),
           startX: selectedSquare.x,
           startY: selectedSquare.y,
           endX: x,
           endY: y,
           progress: 0,
           piece: piece
        });

        setSelectedSquare(null);
        setLegalMoves([]);
        
        setTimeout(() => {
           setGame(newGame);
           if (newGame.status === 'active') {
             handleAIMove(newGame);
           } else {
             onGameOver(newGame.status);
           }
        }, 200);

        return;
      }
    }

    // Select piece
    const piece = game.board[y][x];
    if (piece && piece.color === game.turn) {
      setSelectedSquare({ x, y });
      setLegalMoves(game.getLegalMovesForPiece(x, y));
    } else {
      setSelectedSquare(null);
      setLegalMoves([]);
    }
  };

  return (
    <div className="relative shadow-2xl rounded-lg overflow-hidden border-4 border-slate-700/80">
      <canvas 
        ref={canvasRef} 
        width={BOARD_SIZE} 
        height={BOARD_SIZE} 
        onClick={handleCanvasClick}
        className="block bg-slate-200 cursor-pointer"
        style={{ width: '100%', maxWidth: '640px', height: 'auto', aspectRatio: '1 / 1' }}
      ></canvas>
    </div>
  );
}
