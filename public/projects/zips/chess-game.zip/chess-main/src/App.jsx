import React, { useState, useEffect } from 'react';
import { Game } from './engine/Game';
import ChessBoard from './components/ChessBoard';
import './App.css';

function App() {
  const [game, setGame] = useState(new Game());
  const [gameOverStr, setGameOverStr] = useState(null);

  const handleGameOver = (status) => {
    if (status === 'checkmate') {
      const winner = game.turn === 'w' ? 'Black' : 'White';
      setGameOverStr(`Checkmate! ${winner} Wins!`);
    } else if (status === 'stalemate') {
      setGameOverStr("Draw - Stalemate");
    }
  };

  const restartGame = () => {
    setGame(new Game());
    setGameOverStr(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white flex flex-col items-center py-10 font-sans selection:bg-blue-500/30">
      
      <div className="text-center mb-8">
        <h1 className="text-5xl font-extrabold pb-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400 drop-shadow-lg tracking-tight">
          Minimax Chess
        </h1>
        <p className="text-slate-400 text-lg">Play against the AI (Depth 3)</p>
      </div>

      <div className="w-full max-w-4xl flex flex-col md:flex-row items-start justify-center gap-8 px-4">
        
        {/* Board Section */}
        <div className="w-full max-w-[640px] flex-shrink-0">
          <div className="bg-slate-800 rounded-xl shadow-2xl p-4 border border-slate-700/50 relative">
            
            <ChessBoard 
               game={game} 
               setGame={setGame} 
               onGameOver={handleGameOver} 
            />

            {/* Game Over Overlay */}
            {gameOverStr && (
               <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm flex flex-col items-center justify-center rounded-xl z-20">
                 <h2 className="text-4xl font-bold text-white mb-6 drop-shadow-md">{gameOverStr}</h2>
                 <button 
                   onClick={restartGame}
                   className="px-8 py-3 bg-gradient-to-r from-blue-500 to-emerald-500 hover:from-blue-400 hover:to-emerald-400 rounded-full font-semibold text-lg shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-200"
                 >
                   Play Again
                 </button>
               </div>
            )}
          </div>
        </div>

        {/* Sidebar / Status Section */}
        <div className="w-full md:w-72 flex flex-col gap-6">
          <div className="bg-slate-800/80 backdrop-blur rounded-xl p-6 border border-slate-700/50 shadow-xl">
            <h3 className="text-xl font-bold text-slate-200 mb-4 border-b border-slate-700 pb-2">Game Status</h3>
            
            <div className="flex items-center gap-3 mb-4">
              <div className="text-slate-400 font-medium w-16">Turn:</div>
              <div className="flex items-center gap-2">
                <div className={`w-4 h-4 rounded-full shadow-inner border border-slate-600 ${game.turn === 'w' ? 'bg-white' : 'bg-slate-900'}`}></div>
                <span className="font-semibold text-lg">{game.turn === 'w' ? 'White' : 'Black (AI)'}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-slate-400 font-medium w-16">State:</div>
              <span className={`font-semibold capitalize px-3 py-1 rounded-md text-sm ${
                game.status === 'checkmate' ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 
                game.status === 'active' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 
                'bg-slate-500/20 text-slate-400 border border-slate-500/30'
              }`}>
                {game.status}
              </span>
            </div>
          </div>

          <div className="bg-slate-800/80 backdrop-blur rounded-xl p-6 border border-slate-700/50 shadow-xl">
            <h3 className="text-xl font-bold text-slate-200 mb-4 border-b border-slate-700 pb-2">Controls</h3>
            <button 
              onClick={restartGame}
              className="w-full py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-medium shadow transition-colors text-slate-200 flex items-center justify-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
              Restart Game
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}

export default App;
