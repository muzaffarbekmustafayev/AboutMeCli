export const PieceType = {
  PAWN: 'p',
  KNIGHT: 'n',
  BISHOP: 'b',
  ROOK: 'r',
  QUEEN: 'q',
  KING: 'k'
};

export const Color = {
  WHITE: 'w',
  BLACK: 'b'
};

export class Game {
  constructor() {
    this.board = this.createInitialBoard();
    this.turn = Color.WHITE;
    this.moveHistory = [];
    this.status = 'active'; // 'active', 'checkmate', 'stalemate'
    this.enPassantTarget = null; // {x, y} coordinate of target square for en passant
    this.castlingRights = {
      w: { k: true, q: true },
      b: { k: true, q: true }
    };
  }

  createInitialBoard() {
    const board = Array(8).fill(null).map(() => Array(8).fill(null));
    const setupRow = (row, color) => {
      const order = [PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN, PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK];
      for (let x = 0; x < 8; x++) board[row][x] = { type: order[x], color };
      for (let x = 0; x < 8; x++) board[row === 0 ? 1 : 6][x] = { type: PieceType.PAWN, color };
    };
    setupRow(0, Color.BLACK);
    setupRow(7, Color.WHITE);
    return board;
  }

  // Generate all pseudo-legal moves for a piece at (startX, startY)
  // Pseudo-legal meaning it moves according to rules, but might leave king in check
  getPseudoLegalMoves(startX, startY) {
    const piece = this.board[startY][startX];
    if (!piece) return [];
    
    let moves = [];
    const color = piece.color;
    const isWhite = color === Color.WHITE;
    const dir = isWhite ? -1 : 1; // white moves up (-y), black moves down (+y)

    const addMove = (endX, endY) => {
      if (endX < 0 || endX > 7 || endY < 0 || endY > 7) return false; // out of bounds
      const target = this.board[endY][endX];
      if (target && target.color === color) return false; // blocked by own piece
      
      moves.push({ startX, startY, endX, endY, capturedData: target });
      return target === null; // return true if empty (to continue sliding pieces)
    };

    switch (piece.type) {
      case PieceType.PAWN:
        // move forward 1
        if (startY + dir >= 0 && startY + dir <= 7 && !this.board[startY + dir][startX]) {
          moves.push({ startX, startY, endX: startX, endY: startY + dir });
          // double move from start
          const startRow = isWhite ? 6 : 1;
          if (startY === startRow && !this.board[startY + dir * 2][startX]) {
            moves.push({ startX, startY, endX: startX, endY: startY + dir * 2 });
          }
        }
        // captures
        for (let dx of [-1, 1]) {
          const nx = startX + dx;
          const ny = startY + dir;
          if (nx >= 0 && nx <= 7 && ny >= 0 && ny <= 7) {
            const target = this.board[ny][nx];
            if (target && target.color !== color) {
              moves.push({ startX, startY, endX: nx, endY: ny, capturedData: target });
            } else if (this.enPassantTarget && this.enPassantTarget.x === nx && this.enPassantTarget.y === ny) {
              moves.push({ startX, startY, endX: nx, endY: ny, flags: 'ep' });
            }
          }
        }
        break;
      
      case PieceType.KNIGHT:
        const knightMoves = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
        knightMoves.forEach(([dx, dy]) => addMove(startX + dx, startY + dy));
        break;

      case PieceType.BISHOP:
        const bishopDirs = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
        bishopDirs.forEach(([dx, dy]) => {
          for (let nx = startX + dx, ny = startY + dy; ; nx += dx, ny += dy) {
            if (!addMove(nx, ny)) break;
          }
        });
        break;

      case PieceType.ROOK:
        const rookDirs = [[0, -1], [0, 1], [-1, 0], [1, 0]];
        rookDirs.forEach(([dx, dy]) => {
          for (let nx = startX + dx, ny = startY + dy; ; nx += dx, ny += dy) {
            if (!addMove(nx, ny)) break;
          }
        });
        break;

      case PieceType.QUEEN:
        const queenDirs = [[-1, -1], [-1, 1], [1, -1], [1, 1], [0, -1], [0, 1], [-1, 0], [1, 0]];
        queenDirs.forEach(([dx, dy]) => {
          for (let nx = startX + dx, ny = startY + dy; ; nx += dx, ny += dy) {
            if (!addMove(nx, ny)) break;
          }
        });
        break;

      case PieceType.KING:
        const kingDirs = [[-1, -1], [-1, 1], [1, -1], [1, 1], [0, -1], [0, 1], [-1, 0], [1, 0]];
        kingDirs.forEach(([dx, dy]) => addMove(startX + dx, startY + dy));
        
        // Castling logic will be handled later
        break;
    }
    return moves;
  }

  // Get all pseudo-legal moves for a specific color
  getAllPseudoLegalMoves(color) {
    let moves = [];
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        const p = this.board[y][x];
        if (p && p.color === color) {
          moves = moves.concat(this.getPseudoLegalMoves(x, y));
        }
      }
    }
    return moves;
  }

  // Returns true if the square (x, y) is attacked by the specified defendingColor
  // Wait, if defendingColor is white, then check if black attacks it.
  isSquareAttacked(x, y, defendingColor) {
    const oppColor = defendingColor === Color.WHITE ? Color.BLACK : Color.WHITE;
    const oppMoves = this.getAllPseudoLegalMoves(oppColor);
    return oppMoves.some(m => m.endX === x && m.endY === y);
  }

  inCheck(color) {
    let kx = -1, ky = -1;
    for (let y = 0; y < 8; y++) {
      if (kx !== -1) break;
      for (let x = 0; x < 8; x++) {
        const p = this.board[y][x];
        if (p && p.type === PieceType.KING && p.color === color) {
          kx = x; ky = y;
          break;
        }
      }
    }
    return this.isSquareAttacked(kx, ky, color);
  }

  // Get true legal moves with king-safety checks
  getLegalMovesForPiece(startX, startY) {
    const piece = this.board[startY][startX];
    if (!piece || piece.color !== this.turn) return [];
    
    let pseudoMoves = this.getPseudoLegalMoves(startX, startY);
    let legalMoves = [];

    for (let move of pseudoMoves) {
      // simulate move
      const targetPiece = this.board[move.endY][move.endX];
      this.board[move.endY][move.endX] = piece;
      this.board[startY][startX] = null;
      let epCaptured = null;
      
      if (move.flags === 'ep') {
        const epY = move.startY;
        epCaptured = this.board[epY][move.endX];
        this.board[epY][move.endX] = null;
      }

      if (!this.inCheck(this.turn)) {
        legalMoves.push(move);
      }

      // undo simulate
      this.board[startY][startX] = piece;
      this.board[move.endY][move.endX] = targetPiece;
      if (move.flags === 'ep') {
         this.board[move.startY][move.endX] = epCaptured;
      }
    }

    // Add castling if king
    if (piece.type === PieceType.KING && !this.inCheck(this.turn)) {
      const row = this.turn === Color.WHITE ? 7 : 0;
      if (startY === row && startX === 4) {
        // kingside
        if (this.castlingRights[this.turn].k && 
            !this.board[row][5] && !this.board[row][6] &&
            !this.isSquareAttacked(5, row, this.turn) && !this.isSquareAttacked(6, row, this.turn)) {
          legalMoves.push({ startX, startY, endX: 6, endY: row, flags: 'k' });
        }
        // queenside
        if (this.castlingRights[this.turn].q && 
            !this.board[row][3] && !this.board[row][2] && !this.board[row][1] &&
            !this.isSquareAttacked(3, row, this.turn) && !this.isSquareAttacked(2, row, this.turn)) {
          legalMoves.push({ startX, startY, endX: 2, endY: row, flags: 'q' });
        }
      }
    }

    return legalMoves;
  }

  getAllLegalMoves() {
    let moves = [];
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        if (this.board[y][x] && this.board[y][x].color === this.turn) {
          moves = moves.concat(this.getLegalMovesForPiece(x, y));
        }
      }
    }
    return moves;
  }

  // Execute a move if it's legal
  makeMove(startX, startY, endX, endY) {
    if (this.status !== 'active') return false;

    const legalMoves = this.getLegalMovesForPiece(startX, startY);
    const m = legalMoves.find(mv => mv.endX === endX && mv.endY === endY);
    if (!m) return false;

    const piece = this.board[startY][startX];
    let captured = this.board[endY][endX];
    
    // Castling logic (move rook)
    if (m.flags === 'k') {
      this.board[endY][5] = this.board[endY][7];
      this.board[endY][7] = null;
    } else if (m.flags === 'q') {
      this.board[endY][3] = this.board[endY][0];
      this.board[endY][0] = null;
    }

    // En Passant capture
    if (m.flags === 'ep') {
      captured = this.board[startY][endX];
      this.board[startY][endX] = null; 
    }

    this.board[endY][endX] = piece;
    this.board[startY][startX] = null;

    // Promotion (auto-queen for simplicity)
    if (piece.type === PieceType.PAWN && (endY === 0 || endY === 7)) {
       this.board[endY][endX] = { type: PieceType.QUEEN, color: piece.color };
    }

    // Update castling rights
    if (piece.type === PieceType.KING) {
      this.castlingRights[piece.color].k = false;
      this.castlingRights[piece.color].q = false;
    } else if (piece.type === PieceType.ROOK) {
      if (startX === 0) this.castlingRights[piece.color].q = false;
      if (startX === 7) this.castlingRights[piece.color].k = false;
    }
    
    // Update en passant target for next turn
    if (piece.type === PieceType.PAWN && Math.abs(startY - endY) === 2) {
      this.enPassantTarget = { x: startX, y: (startY + endY) / 2 };
    } else {
      this.enPassantTarget = null;
    }

    this.turn = this.turn === Color.WHITE ? Color.BLACK : Color.WHITE;
    
    this.updateStatus();
    
    return true; 
  }
  
  updateStatus() {
    const moves = this.getAllLegalMoves();
    if (moves.length === 0) {
      if (this.inCheck(this.turn)) {
        this.status = 'checkmate';
      } else {
        this.status = 'stalemate';
      }
    }
  }

  // Clone method for AI Minimax tree simulation
  clone() {
    const cloneGame = new Game();
    cloneGame.board = this.board.map(row => row.map(cell => cell ? {...cell} : null));
    cloneGame.turn = this.turn;
    cloneGame.status = this.status;
    cloneGame.enPassantTarget = this.enPassantTarget ? {...this.enPassantTarget} : null;
    cloneGame.castlingRights = {
      w: {...this.castlingRights.w},
      b: {...this.castlingRights.b}
    };
    return cloneGame;
  }
}
