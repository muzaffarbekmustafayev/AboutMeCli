import { PieceType, Color, Game } from './Game';

const evaluatePiece = (piece) => {
  if (!piece) return 0;
  let val = 0;
  switch (piece.type) {
    case PieceType.PAWN: val = 10; break;
    case PieceType.KNIGHT: val = 30; break;
    case PieceType.BISHOP: val = 30; break;
    case PieceType.ROOK: val = 50; break;
    case PieceType.QUEEN: val = 90; break;
    case PieceType.KING: val = 900; break;
  }
  return piece.color === Color.WHITE ? val : -val;
};

const evaluateBoard = (game) => {
  if (game.status === 'checkmate') {
    return game.turn === Color.WHITE ? -9999 : 9999;
  }
  if (game.status === 'stalemate') {
    return 0;
  }

  let score = 0;
  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      score += evaluatePiece(game.board[y][x]);
    }
  }
  return score;
};

// Returns { score, move }
export const minimax = (game, depth, alpha, beta, isMaximizingPlayer) => {
  if (depth === 0 || game.status !== 'active') {
    return { score: evaluateBoard(game) };
  }

  const moves = game.getAllLegalMoves();
  
  // Sort moves slightly for better alpha-beta pruning? (optional, skip for simplicity unless too slow)
  
  if (moves.length === 0) {
    return { score: evaluateBoard(game) };
  }

  if (isMaximizingPlayer) {
    let bestScore = -Infinity;
    let bestMove = null;

    for (let i = 0; i < moves.length; i++) {
      const move = moves[i];
      const clone = game.clone();
      clone.makeMove(move.startX, move.startY, move.endX, move.endY);
      
      const currentScore = minimax(clone, depth - 1, alpha, beta, false).score;
      if (currentScore > bestScore) {
        bestScore = currentScore;
        bestMove = move;
      }
      alpha = Math.max(alpha, bestScore);
      if (beta <= alpha) break; // beta cutoff
    }
    return { score: bestScore, move: bestMove };
  } else {
    let bestScore = Infinity;
    let bestMove = null;

    for (let i = 0; i < moves.length; i++) {
      const move = moves[i];
      const clone = game.clone();
      clone.makeMove(move.startX, move.startY, move.endX, move.endY);
      
      const currentScore = minimax(clone, depth - 1, alpha, beta, true).score;
      if (currentScore < bestScore) {
        bestScore = currentScore;
        bestMove = move;
      }
      beta = Math.min(beta, bestScore);
      if (beta <= alpha) break; // alpha cutoff
    }
    return { score: bestScore, move: bestMove };
  }
};

export const getBestMove = (game, depth = 3) => {
  const isMaximizing = game.turn === Color.WHITE;
  return minimax(game, depth, -Infinity, Infinity, isMaximizing).move;
};
