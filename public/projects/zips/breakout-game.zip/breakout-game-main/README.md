# Breakout Game

A modern Breakout-style browser game built with React, Vite, and Tailwind CSS. The project focuses on real-time movement, collision detection, brick breaking, lives, score tracking, and a clean game-first interface.

## Project Demo

![Breakout Game Demo](./project-demo.png)

## Live Preview

[Open the live demo](https://breakout-game-pied.vercel.app)

## Features

- Breakout gameplay with paddle, ball, and brick grid
- Real-time canvas rendering with `requestAnimationFrame`
- Wall, paddle, and brick collision detection
- Score system with `+10` for each brick
- Lives system
- Win state when all bricks are destroyed
- Game over state when lives run out
- Pause and restart controls
- Keyboard and touch controls
- Responsive layout with a game-focused UI

## Tech Stack

- React
- Vite
- Tailwind CSS
- HTML5 Canvas

## Getting Started

### Prerequisites

- Node.js 18+ recommended
- npm

### Install dependencies

```bash
npm install
```

### Start the development server

```bash
npm run dev
```

### Build for production

```bash
npm run build
```

### Preview the production build

```bash
npm run preview
```

## Controls

- `Left Arrow` or `A`: move paddle left
- `Right Arrow` or `D`: move paddle right
- `Space`: pause or resume
- `R` or `Enter`: restart the game
- Touch buttons: move left or right on smaller screens

## Gameplay

- Break every brick to win
- Each destroyed brick adds `10` points
- The ball bounces off walls and the paddle
- If the ball falls below the paddle, you lose a life
- The game ends when all lives are gone

## Project Structure

```text
breakout-game/
├── index.html
├── package.json
├── vite.config.js
├── project-demo.png
└── src/
    ├── App.jsx
    ├── main.jsx
    └── index.css
```

## Notes

- Tailwind CSS is integrated through the Vite plugin.
- The main game loop and collision logic live in `src/App.jsx`.
- `node_modules`, `dist`, logs, and local editor files are already ignored in `.gitignore`.
