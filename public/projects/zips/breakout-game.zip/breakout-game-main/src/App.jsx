import { useEffect, useRef, useState } from "react";

const GAME = {
  width: 960,
  height: 640,
  paddleWidth: 168,
  paddleHeight: 18,
  paddleSpeed: 10,
  paddleY: 586,
  ballRadius: 10,
  startBallSpeed: 5.4,
  brickRows: 6,
  brickCols: 10,
  brickWidth: 78,
  brickHeight: 24,
  brickGap: 10,
  brickTop: 82,
  brickScore: 10,
  lives: 3,
};

const BRICK_COLORS = ["#f97316", "#fb7185", "#f59e0b", "#84cc16", "#14b8a6", "#38bdf8"];
const BRICK_LEFT =
  (GAME.width -
    (GAME.brickCols * GAME.brickWidth + (GAME.brickCols - 1) * GAME.brickGap)) /
  2;

function createBricks() {
  const bricks = [];

  for (let row = 0; row < GAME.brickRows; row += 1) {
    for (let col = 0; col < GAME.brickCols; col += 1) {
      bricks.push({
        id: `${row}-${col}`,
        x: BRICK_LEFT + col * (GAME.brickWidth + GAME.brickGap),
        y: GAME.brickTop + row * (GAME.brickHeight + GAME.brickGap),
        width: GAME.brickWidth,
        height: GAME.brickHeight,
        color: BRICK_COLORS[row % BRICK_COLORS.length],
        alive: true,
      });
    }
  }

  return bricks;
}

function createBall() {
  return {
    x: GAME.width / 2,
    y: GAME.height * 0.56,
    radius: GAME.ballRadius,
    vx: Math.random() > 0.5 ? GAME.startBallSpeed : -GAME.startBallSpeed,
    vy: -GAME.startBallSpeed,
  };
}

function createGameState() {
  return {
    paddle: {
      x: (GAME.width - GAME.paddleWidth) / 2,
      y: GAME.paddleY,
      width: GAME.paddleWidth,
      height: GAME.paddleHeight,
    },
    ball: createBall(),
    bricks: createBricks(),
    score: 0,
    lives: GAME.lives,
    status: "running",
    bricksLeft: GAME.brickRows * GAME.brickCols,
    controls: {
      left: false,
      right: false,
    },
  };
}

function drawRoundedRect(ctx, x, y, width, height, radius) {
  const safeRadius = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + safeRadius, y);
  ctx.arcTo(x + width, y, x + width, y + height, safeRadius);
  ctx.arcTo(x + width, y + height, x, y + height, safeRadius);
  ctx.arcTo(x, y + height, x, y, safeRadius);
  ctx.arcTo(x, y, x + width, y, safeRadius);
  ctx.closePath();
}

function syncBallSpeed(ball) {
  const baseSpeed = Math.hypot(ball.vx, ball.vy) || 1;
  let currentSpeed = baseSpeed;

  if (currentSpeed < 3.5) {
    currentSpeed = 3.5;
  }

  if (currentSpeed > 12) {
    currentSpeed = 12;
  }

  const normalizedX = ball.vx / baseSpeed;
  const normalizedY = ball.vy / baseSpeed;

  ball.vx = normalizedX * currentSpeed;
  ball.vy = normalizedY * currentSpeed;
}

function circleRectCollision(ball, brick) {
  const closestX = Math.max(brick.x, Math.min(ball.x, brick.x + brick.width));
  const closestY = Math.max(brick.y, Math.min(ball.y, brick.y + brick.height));
  const distanceX = ball.x - closestX;
  const distanceY = ball.y - closestY;

  return distanceX * distanceX + distanceY * distanceY <= ball.radius * ball.radius;
}

function drawScene(ctx, game) {
  ctx.clearRect(0, 0, GAME.width, GAME.height);

  const bgGradient = ctx.createLinearGradient(0, 0, 0, GAME.height);
  bgGradient.addColorStop(0, "#071421");
  bgGradient.addColorStop(1, "#102132");
  ctx.fillStyle = bgGradient;
  ctx.fillRect(0, 0, GAME.width, GAME.height);

  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.05)";
  ctx.lineWidth = 1;
  for (let x = 0; x <= GAME.width; x += 48) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, GAME.height);
    ctx.stroke();
  }
  for (let y = 0; y <= GAME.height; y += 48) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(GAME.width, y);
    ctx.stroke();
  }
  ctx.restore();

  game.bricks.forEach((brick) => {
    if (!brick.alive) {
      return;
    }

    drawRoundedRect(ctx, brick.x, brick.y, brick.width, brick.height, 8);
    const brickGradient = ctx.createLinearGradient(brick.x, brick.y, brick.x, brick.y + brick.height);
    brickGradient.addColorStop(0, brick.color);
    brickGradient.addColorStop(1, "#0f172a");
    ctx.fillStyle = brickGradient;
    ctx.fill();

    ctx.fillStyle = "rgba(255,255,255,0.18)";
    drawRoundedRect(ctx, brick.x + 5, brick.y + 4, brick.width - 10, 5, 4);
    ctx.fill();
  });

  ctx.save();
  const paddle = game.paddle;
  drawRoundedRect(ctx, paddle.x, paddle.y, paddle.width, paddle.height, 10);
  const paddleGradient = ctx.createLinearGradient(paddle.x, paddle.y, paddle.x + paddle.width, paddle.y);
  paddleGradient.addColorStop(0, "#f8fafc");
  paddleGradient.addColorStop(0.5, "#a7f3d0");
  paddleGradient.addColorStop(1, "#22c55e");
  ctx.fillStyle = paddleGradient;
  ctx.shadowColor = "rgba(56, 189, 248, 0.34)";
  ctx.shadowBlur = 22;
  ctx.fill();
  ctx.restore();

  ctx.save();
  const ball = game.ball;
  const ballGradient = ctx.createRadialGradient(
    ball.x - ball.radius / 3,
    ball.y - ball.radius / 3,
    2,
    ball.x,
    ball.y,
    ball.radius + 5
  );
  ballGradient.addColorStop(0, "#ffffff");
  ballGradient.addColorStop(0.45, "#fde68a");
  ballGradient.addColorStop(1, "#fb7185");
  ctx.fillStyle = ballGradient;
  ctx.shadowColor = "rgba(249, 115, 22, 0.45)";
  ctx.shadowBlur = 28;
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.fillStyle = "rgba(255,255,255,0.16)";
  ctx.fillRect(22, GAME.height - 38, GAME.width - 44, 1);
  ctx.restore();
}

export default function App() {
  const canvasRef = useRef(null);
  const frameRef = useRef(0);
  const previousTimeRef = useRef(0);
  const gameRef = useRef(createGameState());

  const [hud, setHud] = useState({
    score: 0,
    lives: GAME.lives,
    status: "running",
    bricksLeft: GAME.brickRows * GAME.brickCols,
  });
  const [controls, setControls] = useState({
    left: false,
    right: false,
  });

  function syncHud() {
    const game = gameRef.current;
    setHud({
      score: game.score,
      lives: game.lives,
      status: game.status,
      bricksLeft: game.bricksLeft,
    });
  }

  function restartGame() {
    gameRef.current = createGameState();
    previousTimeRef.current = 0;
    setControls({
      left: false,
      right: false,
    });
    syncHud();
  }

  function togglePause() {
    const game = gameRef.current;

    if (game.status === "gameover" || game.status === "win") {
      return;
    }

    game.status = game.status === "running" ? "paused" : "running";
    previousTimeRef.current = 0;
    game.controls.left = false;
    game.controls.right = false;
    setControls({
      left: false,
      right: false,
    });
    syncHud();
  }

  function setControl(direction, isPressed) {
    const game = gameRef.current;
    game.controls[direction] = isPressed;

    setControls((current) => {
      if (current[direction] === isPressed) {
        return current;
      }

      return {
        ...current,
        [direction]: isPressed,
      };
    });
  }

  useEffect(() => {
    const handleKeyDown = (event) => {
      const key = event.key.toLowerCase();

      if (["arrowleft", "arrowright", "a", "d", " ", "r", "enter"].includes(key)) {
        event.preventDefault();
      }

      if (event.repeat && (key === " " || key === "r" || key === "enter")) {
        return;
      }

      if (key === "arrowleft" || key === "a") {
        setControl("left", true);
      } else if (key === "arrowright" || key === "d") {
        setControl("right", true);
      } else if (key === " ") {
        togglePause();
      } else if (key === "r" || key === "enter") {
        restartGame();
      }
    };

    const handleKeyUp = (event) => {
      const key = event.key.toLowerCase();

      if (key === "arrowleft" || key === "a") {
        setControl("left", false);
      } else if (key === "arrowright" || key === "d") {
        setControl("right", false);
      }
    };

    const handleWindowBlur = () => {
      gameRef.current.controls.left = false;
      gameRef.current.controls.right = false;
      setControls({
        left: false,
        right: false,
      });
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    window.addEventListener("blur", handleWindowBlur);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
      window.removeEventListener("blur", handleWindowBlur);
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    const loop = (time) => {
      const game = gameRef.current;
      const rawDelta = previousTimeRef.current === 0 ? 1 : (time - previousTimeRef.current) / 16.6667;
      const delta = Math.min(rawDelta, 2);
      previousTimeRef.current = time;

      if (game.status === "running") {
        const moveAmount = GAME.paddleSpeed * delta;

        if (game.controls.left) {
          game.paddle.x -= moveAmount;
        }

        if (game.controls.right) {
          game.paddle.x += moveAmount;
        }

        game.paddle.x = Math.max(0, Math.min(GAME.width - game.paddle.width, game.paddle.x));

        const previousY = game.ball.y;

        game.ball.x += game.ball.vx * delta;
        game.ball.y += game.ball.vy * delta;

        if (game.ball.x - game.ball.radius <= 0) {
          game.ball.x = game.ball.radius;
          game.ball.vx = Math.abs(game.ball.vx);
        }

        if (game.ball.x + game.ball.radius >= GAME.width) {
          game.ball.x = GAME.width - game.ball.radius;
          game.ball.vx = -Math.abs(game.ball.vx);
        }

        if (game.ball.y - game.ball.radius <= 0) {
          game.ball.y = game.ball.radius;
          game.ball.vy = Math.abs(game.ball.vy);
        }

        const paddle = game.paddle;
        if (
          game.ball.vy > 0 &&
          previousY + game.ball.radius <= paddle.y &&
          game.ball.y + game.ball.radius >= paddle.y &&
          game.ball.x + game.ball.radius >= paddle.x &&
          game.ball.x - game.ball.radius <= paddle.x + paddle.width
        ) {
          const impact = (game.ball.x - (paddle.x + paddle.width / 2)) / (paddle.width / 2);
          const speed = Math.min(11.4, Math.hypot(game.ball.vx, game.ball.vy) + 0.18);

          game.ball.x = Math.max(
            game.ball.radius,
            Math.min(GAME.width - game.ball.radius, game.ball.x)
          );
          game.ball.y = paddle.y - game.ball.radius - 1;
          game.ball.vx = impact * speed * 0.95;

          if (Math.abs(game.ball.vx) < 1.4) {
            game.ball.vx = impact >= 0 ? 1.4 : -1.4;
          }

          const nextVy = Math.sqrt(Math.max(14, speed * speed - game.ball.vx * game.ball.vx));
          game.ball.vy = -nextVy;
          syncBallSpeed(game.ball);
        }

        for (let index = 0; index < game.bricks.length; index += 1) {
          const brick = game.bricks[index];

          if (!brick.alive || !circleRectCollision(game.ball, brick)) {
            continue;
          }

          brick.alive = false;
          game.score += GAME.brickScore;
          game.bricksLeft -= 1;

          const overlapLeft = game.ball.x + game.ball.radius - brick.x;
          const overlapRight = brick.x + brick.width - (game.ball.x - game.ball.radius);
          const overlapTop = game.ball.y + game.ball.radius - brick.y;
          const overlapBottom = brick.y + brick.height - (game.ball.y - game.ball.radius);
          const minOverlap = Math.min(overlapLeft, overlapRight, overlapTop, overlapBottom);

          if (minOverlap === overlapLeft) {
            game.ball.x = brick.x - game.ball.radius;
            game.ball.vx = -Math.abs(game.ball.vx);
          } else if (minOverlap === overlapRight) {
            game.ball.x = brick.x + brick.width + game.ball.radius;
            game.ball.vx = Math.abs(game.ball.vx);
          } else if (minOverlap === overlapTop) {
            game.ball.y = brick.y - game.ball.radius;
            game.ball.vy = -Math.abs(game.ball.vy);
          } else {
            game.ball.y = brick.y + brick.height + game.ball.radius;
            game.ball.vy = Math.abs(game.ball.vy);
          }

          const boostedSpeed = Math.min(11.8, Math.hypot(game.ball.vx, game.ball.vy) + 0.04);
          const normalized = boostedSpeed / Math.hypot(game.ball.vx, game.ball.vy);
          game.ball.vx *= normalized;
          game.ball.vy *= normalized;
          syncHud();
          break;
        }

        if (game.bricksLeft === 0) {
          game.status = "win";
          syncHud();
        } else if (game.ball.y - game.ball.radius > GAME.height) {
          game.lives -= 1;

          if (game.lives <= 0) {
            game.status = "gameover";
          } else {
            game.paddle.x = (GAME.width - game.paddle.width) / 2;
            game.ball = createBall();
          }

          syncHud();
        }
      }

      drawScene(ctx, gameRef.current);
      frameRef.current = window.requestAnimationFrame(loop);
    };

    frameRef.current = window.requestAnimationFrame(loop);

    return () => {
      window.cancelAnimationFrame(frameRef.current);
    };
  }, []);

  const overlayTitle =
    hud.status === "win" ? "You Win!" : hud.status === "gameover" ? "Game Over" : "Paused";

  function createPointerHandlers(direction) {
    return {
      onPointerDown: (event) => {
        event.preventDefault();
        setControl(direction, true);
      },
      onPointerUp: () => setControl(direction, false),
      onPointerLeave: () => setControl(direction, false),
      onPointerCancel: () => setControl(direction, false),
    };
  }

  return (
    <main className="min-h-screen px-3 py-4 sm:px-4">
      <div className="mx-auto max-w-[1060px]">
        <section className="board-enter overflow-hidden rounded-[1.75rem] border border-white/70 bg-white/80 p-3 shadow-panel backdrop-blur">
          <div className="mb-3 flex flex-col gap-3 border-b border-slate-200/80 pb-3 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.3em] text-tide">Breakout Game</p>
              <h1 className="mt-1.5 text-xl font-bold tracking-tight sm:text-2xl">Breakout Reactor</h1>
            </div>

            <div className="grid grid-cols-3 gap-2 md:min-w-[285px]">
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-slate-500">
                  Score
                </p>
                <p className="mt-1 text-xl font-bold">{hud.score}</p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-slate-500">
                  Lives
                </p>
                <p className="mt-1 text-xl font-bold">{hud.lives}</p>
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-slate-500">
                  Bricks
                </p>
                <p className="mt-1 text-xl font-bold">{hud.bricksLeft}</p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="mx-auto max-w-[820px]">
              <div className="relative overflow-hidden rounded-[1.4rem] border border-slate-200 bg-slate-950 p-2 shadow-2xl shadow-slate-900/20">
                <div className="canvas-shell glow-ring overflow-hidden rounded-[1.1rem] border border-white/5 p-1.5 sm:p-2">
                  <canvas
                    ref={canvasRef}
                    width={GAME.width}
                    height={GAME.height}
                    className="block aspect-[3/2] w-full rounded-[0.9rem]"
                  />
                </div>

                {hud.status !== "running" && (
                  <div className="absolute inset-0 flex items-center justify-center bg-slate-950/70 p-6 text-center">
                    <div className="max-w-sm rounded-[1.75rem] border border-white/10 bg-slate-950/85 p-6 text-white shadow-2xl">
                      <p className="font-mono text-xs uppercase tracking-[0.28em] text-orange-300">
                        {hud.status}
                      </p>
                      <h2 className="mt-3 text-3xl font-bold">{overlayTitle}</h2>
                      <div className="mt-5 flex flex-wrap justify-center gap-3">
                        {hud.status === "paused" && (
                          <button
                            type="button"
                            onClick={togglePause}
                            className="rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-orange-100"
                          >
                            Resume
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={restartGame}
                          className="rounded-2xl bg-flare px-5 py-3 text-sm font-semibold text-white transition hover:bg-orange-500"
                        >
                          Restart
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mx-auto grid max-w-[820px] gap-2 lg:grid-cols-[1fr_1fr_110px_1fr_1fr]">
              <button
                type="button"
                {...createPointerHandlers("left")}
                className={`rounded-xl px-3 py-2 text-sm font-semibold transition ${
                  controls.left
                    ? "bg-slate-950 text-white"
                    : "border border-slate-300 bg-white text-slate-700 hover:border-slate-400"
                }`}
              >
                Move Left
              </button>
              <button
                type="button"
                {...createPointerHandlers("right")}
                className={`rounded-xl px-3 py-2 text-sm font-semibold transition ${
                  controls.right
                    ? "bg-slate-950 text-white"
                    : "border border-slate-300 bg-white text-slate-700 hover:border-slate-400"
                }`}
              >
                Move Right
              </button>
              <div className="rounded-xl border border-orange-200 bg-orange-50 px-3 py-2 text-center text-sm font-semibold text-orange-950">
                60 FPS
              </div>
              <button
                type="button"
                onClick={togglePause}
                disabled={hud.status === "gameover" || hud.status === "win"}
                className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 transition hover:border-slate-400 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {hud.status === "paused" ? "Resume" : "Pause"}
              </button>
              <button
                type="button"
                onClick={restartGame}
                className="rounded-xl bg-ink px-3 py-2 text-sm font-semibold text-white transition hover:bg-slate-800"
              >
                Restart
              </button>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
