import React, { useRef, useEffect } from 'react';

// Generates a subtle full-screen canvas weather effect
export default function WeatherCanvas({ conditionType, timeOfDay = 'day' }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationFrameId;

    // Handle resizing
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    // Particle setups
    let particles = [];
    const maxParticles = conditionType === 'snow' ? 200 : conditionType === 'rain' ? 300 : conditionType === 'cloudy' ? 20 : 0;

    for (let i = 0; i < maxParticles; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            opacity: Math.random() * 0.5 + 0.1,
            speed: conditionType === 'snow' ? Math.random() * 1.5 + 0.5 : conditionType === 'rain' ? Math.random() * 15 + 10 : Math.random() * 0.2 + 0.1,
            radius: conditionType === 'snow' ? Math.random() * 3 + 1 : conditionType === 'cloudy' ? Math.random() * 100 + 50 : Math.random() * 1.5 + 0.5,
            length: conditionType === 'rain' ? Math.random() * 20 + 10 : 0,
            sway: Math.random() * Math.PI * 2 // for snow/clouds
        });
    }

    const render = () => {
      // Background base
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      if (timeOfDay === 'day') {
         if (conditionType === 'clear') {
            gradient.addColorStop(0, '#4facfe');
            gradient.addColorStop(1, '#00f2fe');
         } else if (conditionType === 'cloudy' || conditionType === 'snow') {
            gradient.addColorStop(0, '#8e9eab');
            gradient.addColorStop(1, '#eef2f3');
         } else if (conditionType === 'rain') {
            gradient.addColorStop(0, '#4b6cb7');
            gradient.addColorStop(1, '#182848');
         }
      } else {
         // night
         gradient.addColorStop(0, '#0f2027');
         gradient.addColorStop(0.5, '#203a43');
         gradient.addColorStop(1, '#2c5364');
      }

      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw Particles
      if (conditionType === 'rain') {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let p of particles) {
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + p.length * 0.2, p.y + p.length);
          p.y += p.speed;
          p.x += p.speed * 0.2; // slight wind

          if (p.y > canvas.height) {
            p.y = -p.length;
            p.x = Math.random() * canvas.width;
          }
        }
        ctx.stroke();
      } 
      else if (conditionType === 'snow') {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        for (let p of particles) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fill();

          p.y += p.speed;
          p.sway += 0.02;
          p.x += Math.sin(p.sway) * 1; // drifting

          if (p.y > canvas.height) {
            p.y = -p.radius;
            p.x = Math.random() * canvas.width;
          }
        }
      }
      else if (conditionType === 'cloudy' || conditionType === 'clear' && timeOfDay === 'night') {
         // draw clouds or stars
         for (let p of particles) {
            ctx.beginPath();
            ctx.fillStyle = timeOfDay === 'night' && conditionType === 'clear' 
               ? `rgba(255, 255, 255, ${p.opacity})` 
               : `rgba(255, 255, 255, ${p.opacity * 0.2})`;
            
            ctx.arc(p.x, p.y, timeOfDay === 'night' && conditionType === 'clear' ? p.radius * 0.5 : p.radius, 0, Math.PI * 2);
            ctx.fill();

            p.x += p.speed;
            
            if (p.x - p.radius > canvas.width) {
               p.x = -p.radius;
               p.y = Math.random() * canvas.height;
            }
         }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, [conditionType, timeOfDay]);

  return (
    <canvas 
      ref={canvasRef} 
      className="absolute inset-0 z-0 pointer-events-none"
    />
  );
}
