// Open-Meteo API utility (No API key required)

// Helper to map WMO weather codes to readable conditions and icons
export const getWeatherCondition = (code) => {
  if (code === 0) return { label: 'Clear Sky', type: 'clear' };
  if (code === 1 || code === 2 || code === 3) return { label: 'Partly Cloudy', type: 'cloudy' };
  if (code >= 45 && code <= 48) return { label: 'Foggy', type: 'cloudy' };
  if (code >= 51 && code <= 67) return { label: 'Rain', type: 'rain' };
  if (code >= 80 && code <= 82) return { label: 'Rain Showers', type: 'rain' };
  if (code >= 71 && code <= 86) return { label: 'Snow', type: 'snow' };
  if (code >= 95) return { label: 'Thunderstorm', type: 'rain' }; // simplified mapping
  return { label: 'Unknown', type: 'clear' };
};

// 1. Geocoding API to get list of cities matching the search query
export const searchCityCoordinates = async (cityName) => {
  try {
    const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=5&language=en&format=json`);
    const data = await res.json();
    
    if (!data.results || data.results.length === 0) {
      return [];
    }
    
    return data.results.map(city => ({
      id: city.id,
      name: city.name,
      country: city.country,
      admin1: city.admin1 || '', // State/Region
      lat: city.latitude,
      lon: city.longitude
    }));
  } catch (error) {
    console.error("Geocoding error:", error);
    return [];
  }
};

// 2. Weather API to get Current & Forecast Data
export const getWeatherData = async (lat, lon, unit = 'celsius') => {
  // Free tier constraints limit to certain params, but current + daily is fine.
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto${unit === 'fahrenheit' ? '&temperature_unit=fahrenheit' : ''}`;
    
    const res = await fetch(url);
    const data = await res.json();

    const currentCondition = getWeatherCondition(data.current.weather_code);

    // Format forecast array
    const forecast = data.daily.time.map((timeStr, index) => {
      // timeStr is YYYY-MM-DD
      const date = new Date(timeStr);
      const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
      return {
        date: timeStr,
        dayName: index === 0 ? 'Today' : dayName,
        maxTemp: Math.round(data.daily.temperature_2m_max[index]),
        minTemp: Math.round(data.daily.temperature_2m_min[index]),
        condition: getWeatherCondition(data.daily.weather_code[index])
      };
    });

    return {
      current: {
        temp: Math.round(data.current.temperature_2m),
        humidity: data.current.relative_humidity_2m,
        wind: data.current.wind_speed_10m,
        condition: currentCondition
      },
      forecast: forecast.slice(0, 7) // next 7 days
    };
  } catch (error) {
    console.error("Weather fetch error:", error);
    throw error;
  }
};
