import React from 'react';

export default function Forecast({ forecast }) {
  if (!forecast || forecast.length === 0) return null;

  return (
    <div className="mt-6 w-full animate-fade-in-up">
      <h3 className="text-xl font-bold mb-4 pl-2 drop-shadow-md">7-Day Forecast</h3>
      
      <div className="flex overflow-x-auto pb-4 gap-4 snap-x snap-mandatory hide-scrollbar">
        {forecast.map((day, idx) => (
          <div 
            key={day.date} 
            className="snap-start flex-none glass-dark rounded-2xl p-4 w-32 flex flex-col items-center justify-between hover:bg-white/10 transition-colors border border-white/5"
          >
            <span className="text-lg font-bold mb-1 opacity-90">{day.dayName}</span>
            <span className="text-xs font-medium text-white/50 mb-3">{day.date}</span>
            
            <div className="flex-1 flex flex-col items-center justify-center">
              {/* Very simplistic icons based on condition type */}
              <div className="text-3xl drop-shadow-lg mb-2">
                 {day.condition.type === 'rain' && '🌧️'}
                 {day.condition.type === 'snow' && '❄️'}
                 {day.condition.type === 'cloudy' && '☁️'}
                 {day.condition.type === 'clear' && '☀️'}
              </div>
              <span className="text-xs font-semibold text-center text-white/80 leading-tight h-8 flex items-center">{day.condition.label}</span>
            </div>
            
            <div className="flex items-center justify-center gap-2 w-full mt-3 pt-3 border-t border-white/10">
               <span className="font-bold">{day.maxTemp}°</span>
               <span className="text-white/50 font-medium text-sm">{day.minTemp}°</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
