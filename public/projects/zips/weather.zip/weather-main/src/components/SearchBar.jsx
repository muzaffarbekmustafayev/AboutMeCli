import React, { useState, useEffect, useRef } from 'react';
import { searchCityCoordinates } from '../api/weatherApi';

export default function SearchBar({ onCitySelect, onUseLocation, loading }) {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef(null);
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Debounced search logic
  useEffect(() => {
    const fetchSuggestions = async () => {
      if (query.trim().length < 2) {
        setSuggestions([]);
        return;
      }
      setIsSearching(true);
      const results = await searchCityCoordinates(query);
      setSuggestions(results);
      setIsSearching(false);
      setShowDropdown(true);
    };

    const debounceTimer = setTimeout(fetchSuggestions, 400);
    return () => clearTimeout(debounceTimer);
  }, [query]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (query.trim()) {
      // If user presses enter without selecting, pick the first suggestion if available
      if (suggestions.length > 0) {
        handleSelect(suggestions[0]);
      } else {
        // Fallback fetch just to be safe
        setIsSearching(true);
        const results = await searchCityCoordinates(query);
        if (results.length > 0) handleSelect(results[0]);
        setIsSearching(false);
      }
    }
  };

  const handleSelect = (cityObj) => {
    setQuery('');
    setSuggestions([]);
    setShowDropdown(false);
    onCitySelect(cityObj); // Pass the exact lat/lon directly instead of string
  };

  return (
    <div className="w-full relative z-30 mb-6" ref={dropdownRef}>
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <input 
            type="text" 
            value={query}
            onChange={(e) => {
               setQuery(e.target.value);
               if (e.target.value.trim().length > 1) setShowDropdown(true);
            }}
            onFocus={() => { if (suggestions.length > 0) setShowDropdown(true) }}
            placeholder="Search for a city..."
            className="w-full h-12 rounded-2xl glass-dark px-5 pr-10 text-lg outline-none placeholder:text-white/60 focus:ring-2 focus:ring-white/40 transition-all text-white font-medium"
            disabled={loading}
            autoComplete="off"
          />
          {isSearching ? (
             <div className="absolute right-4 top-3.5">
               <svg className="animate-spin h-5 w-5 text-white/60" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
             </div>
          ) : (
             <svg className="absolute right-4 top-3.5 w-5 h-5 text-white/60" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          )}

          {/* Autocomplete Dropdown */}
          {showDropdown && suggestions.length > 0 && (
            <div className="absolute top-14 left-0 w-full glass-dark rounded-xl overflow-hidden shadow-2xl border border-white/20 animate-fade-in-up">
              <ul className="max-h-60 overflow-y-auto">
                {suggestions.map((city) => (
                  <li 
                    key={city.id} 
                    onClick={() => handleSelect(city)}
                    className="px-4 py-3 hover:bg-white/10 cursor-pointer border-b border-white/5 last:border-b-0 flex flex-col transition-colors"
                  >
                    <span className="font-semibold text-white">{city.name}</span>
                    <span className="text-sm text-white/60">{city.admin1 ? `${city.admin1}, ` : ''}{city.country}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
        
        <button 
          type="button" 
          onClick={onUseLocation}
          disabled={loading}
          className="h-12 px-6 rounded-2xl glass hover:bg-white/20 active:bg-white/30 transition-all flex items-center justify-center gap-2 whitespace-nowrap font-semibold"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
          <span className="hidden sm:inline">My Location</span>
        </button>
      </form>
    </div>
  );
}
