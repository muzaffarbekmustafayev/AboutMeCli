import React from 'react';

// Using simple SVG icons, ideally we use lucide-react but SVG keeps dependencies low
const Icon = ({ type }) => {
  switch (type) {
    case 'clear':
      return <svg className="w-20 h-20 text-yellow-400 drop-shadow-lg" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.25a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0z" /></svg>; // Fake sun icon roughly
    case 'rain':
      return <svg className="w-20 h-20 text-blue-300 drop-shadow-lg" fill="currentColor" viewBox="0 0 24 24"><path d="M17 12a5 5 0 00-10 0 4 4 0 004 4h6a4 4 0 000-8z" /></svg> // Fake rain
    case 'snow':
      return <svg className="w-20 h-20 text-slate-100 drop-shadow-lg" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L12 22 M7 7 L17 17 M17 7 L7 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>; 
    case 'cloudy':
    default:
      return <svg className="w-20 h-20 text-slate-300 drop-shadow-lg" fill="currentColor" viewBox="0 0 24 24"><path fillRule="evenodd" d="M12 5.25a6.75 6.75 0 00-6.65 5.5A4.5 4.5 0 005.5 19.5h13a4.5 4.5 0 001.05-8.875A6.75 6.75 0 0012 5.25z" clipRule="evenodd" /></svg>;
  }
}

export default function CurrentWeather({ weatherData, location, unit, toggleUnit }) {
  if (!weatherData) return null;

  const current = weatherData.current;

  return (
    <div className="glass rounded-3xl p-6 sm:p-10 w-full animate-fade-in relative overflow-hidden">
      
      {/* Unit Toggle */}
      <div className="absolute top-6 right-6 flex bg-black/20 rounded-full p-1 border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => toggleUnit('celsius')}
          className={`px-3 py-1 rounded-full text-sm font-bold transition-all ${unit === 'celsius' ? 'bg-white text-slate-900 shadow' : 'text-white/60 hover:text-white'}`}
        >
          °C
        </button>
        <button 
          onClick={() => toggleUnit('fahrenheit')}
          className={`px-3 py-1 rounded-full text-sm font-bold transition-all ${unit === 'fahrenheit' ? 'bg-white text-slate-900 shadow' : 'text-white/60 hover:text-white'}`}
        >
          °F
        </button>
      </div>

      <div className="text-center sm:text-left flex flex-col sm:flex-row items-center justify-between gap-8 mt-6">
        <div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mb-1">{location.name}</h2>
          <p className="text-lg text-white/80 font-medium mb-6">{location.country}</p>
          
          <div className="flex items-center justify-center sm:justify-start gap-4">
             <h1 className="text-7xl sm:text-8xl font-black drop-shadow-xl tracking-tighter">
                {current.temp}°
             </h1>
             <div className="flex flex-col items-start ml-2">
                <Icon type={current.condition.type} />
                <span className="text-xl font-bold tracking-wide uppercase text-white/90 drop-shadow mt-1 ml-1">{current.condition.label}</span>
             </div>
          </div>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-2 gap-4 w-full sm:w-auto mt-6 sm:mt-0">
          <div className="glass-dark rounded-2xl p-4 flex flex-col items-center justify-center min-w-[120px]">
             <svg className="w-7 h-7 mb-2 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
             <span className="text-white/60 text-sm font-medium mb-1">Humidity</span>
             <span className="text-2xl font-bold">{current.humidity}%</span>
          </div>
          <div className="glass-dark rounded-2xl p-4 flex flex-col items-center justify-center min-w-[120px]">
             <svg className="w-7 h-7 mb-2 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
             <span className="text-white/60 text-sm font-medium mb-1">Wind</span>
             <span className="text-2xl font-bold">{current.wind} <span className="text-base text-white/60">km/h</span></span>
          </div>
        </div>
      </div>
    </div>
  );
}
