import React, { useState, useEffect } from 'react';
import SearchBar from './components/SearchBar';
import CurrentWeather from './components/CurrentWeather';
import Forecast from './components/Forecast';
import WeatherCanvas from './animations/WeatherCanvas';
import { searchCityCoordinates, getWeatherData } from './api/weatherApi';
import './App.css';

function App() {
  const [weatherData, setWeatherData] = useState(null);
  const [location, setLocation] = useState(null);
  const [unit, setUnit] = useState('celsius');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Default load Tashkent if no geolocation
  useEffect(() => {
    // We can do a manual search for Tashkent on mount
    const loadDefault = async () => {
       const res = await searchCityCoordinates('Tashkent');
       if (res.length > 0) handleCitySelect(res[0]);
    };
    loadDefault();
  }, []);

  const fetchWeatherForCoords = async (lat, lon, name, country, currentUnit = unit) => {
    setLoading(true);
    setError(null);
    try {
      const data = await getWeatherData(lat, lon, currentUnit);
      setWeatherData(data);
      setLocation({ name, country, lat, lon });
    } catch (err) {
      setError(err.message || 'Failed to fetch weather data.');
    } finally {
      setLoading(false);
    }
  };

  const handleCitySelect = async (cityObj) => {
    // City object comes directly from the SearchBar autocomplete
    await fetchWeatherForCoords(cityObj.lat, cityObj.lon, cityObj.name, cityObj.country, unit);
  };

  const handleGeolocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }
    
    setLoading(true);
    navigator.geolocation.getCurrentPosition(async (position) => {
      // Reverse geocoding optional, we'll just say "My Location" for now
      await fetchWeatherForCoords(
        position.coords.latitude, 
        position.coords.longitude, 
        'My Location', 
        '',
        unit
      );
    }, (err) => {
      setError('Failed to get your location. Please ensure location services are enabled.');
      setLoading(false);
    });
  };

  const toggleUnit = async (newUnit) => {
    if (newUnit === unit || !location) return;
    setUnit(newUnit);
    // Refetch with new unit
    await fetchWeatherForCoords(location.lat, location.lon, location.name, location.country, newUnit);
  };

  // Determine background based on current time (rough) and weather code
  const isNight = new Date().getHours() >= 19 || new Date().getHours() <= 5;
  const timeOfDay = isNight ? 'night' : 'day';
  const conditionType = weatherData?.current?.condition?.type || 'clear';

  return (
    <div className="relative w-full h-screen overflow-hidden text-white font-sans selection:bg-white/30">
      
      {/* Background Canvas Layer */}
      <WeatherCanvas conditionType={conditionType} timeOfDay={timeOfDay} />

      {/* Main UI Layer */}
      <main className="relative z-10 w-full h-full overflow-y-auto px-4 py-8 custom-scrollbar">
        <div className="max-w-3xl mx-auto flex flex-col items-center">
          
          <h1 className="text-4xl sm:text-5xl font-extrabold mb-8 drop-shadow-lg tracking-tight text-center">
            Weather<span className="text-blue-300">Space</span>
          </h1>

          <SearchBar 
            onCitySelect={handleCitySelect} 
            onUseLocation={handleGeolocation} 
            loading={loading} 
          />

          {error && (
            <div className="w-full glass-dark border border-red-500/50 bg-red-500/10 text-red-200 rounded-xl p-4 mb-6 text-center shadow-lg">
              {error}
            </div>
          )}

          {loading && !weatherData && (
             <div className="w-full flex justify-center py-20">
               <svg className="animate-spin h-10 w-10 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
             </div>
          )}

          {!loading && weatherData && location && (
            <div className="w-full space-y-6 flex flex-col items-center">
              <CurrentWeather 
                 weatherData={weatherData} 
                 location={location} 
                 unit={unit} 
                 toggleUnit={toggleUnit} 
              />
              <Forecast forecast={weatherData.forecast} />
            </div>
          )}

        </div>
      </main>
    </div>
  );
}

export default App;
