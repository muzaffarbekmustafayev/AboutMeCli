# WeatherSpace 🌤️

A beautiful real-time weather app built with React + Vite. Features animated weather backgrounds, city search with autocomplete, geolocation support, and a 7-day forecast.

🚀 **Live Demo:** [https://weather-five-chi-39.vercel.app](https://weather-five-chi-39.vercel.app)

![WeatherSpace Demo](./project-demo.png)

## Features

- 🔍 City search with autocomplete
- 📍 Geolocation support — get weather for your current location
- 🌡️ Celsius / Fahrenheit toggle
- 🎨 Dynamic animated backgrounds based on time of day and weather condition
- 📅 7-day forecast
- ⚡ Powered by [Open-Meteo](https://open-meteo.com/) — free, no API key needed

## Tech Stack

| Tool | Version |
|------|---------|
| [React](https://react.dev/) | 19 |
| [Vite](https://vite.dev/) | 8 |
| [Tailwind CSS](https://tailwindcss.com/) | latest |
| [Open-Meteo API](https://open-meteo.com/) | — |

## Getting Started

```bash
# Clone the repository
git clone https://github.com/your-username/weather-app.git
cd weather-app

# Install dependencies
npm install

# Start dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Other Commands

```bash
npm run build    # Build for production
npm run preview  # Preview production build
npm run lint     # Run ESLint
```

## Project Structure

```
weather-app/
├── public/
│   ├── favicon.svg
│   └── icons.svg
├── src/
│   ├── api/
│   │   └── weatherApi.js       # Open-Meteo API calls
│   ├── animations/
│   │   └── WeatherCanvas.jsx   # Canvas-based weather animations
│   ├── components/
│   │   ├── SearchBar.jsx       # City search with autocomplete
│   │   ├── CurrentWeather.jsx  # Current weather display
│   │   └── Forecast.jsx        # 7-day forecast
│   ├── App.jsx                 # Root component
│   └── main.jsx
├── index.html
└── vite.config.js
```

## License

MIT
