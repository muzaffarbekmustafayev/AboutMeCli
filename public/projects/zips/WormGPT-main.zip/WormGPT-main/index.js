import axios from "axios";
import readline from "readline";
import chalk from "chalk";
import dotenv from "dotenv";
dotenv.config();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: chalk.green("Siz: "),
});

console.log(chalk.cyan("🤖 Gemini bilan chatga xush kelibsiz!"));
rl.prompt();

rl.on("line", async (input) => {
  if (!input.trim()) return rl.prompt();
  if (input.toLowerCase() === "exit") {
    console.log(chalk.yellow("Chat yakunlandi."));
    process.exit(0);
  }

  try {
    const res = await axios.post(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        contents: [{ parts: [{ text: input }] }],
      },
      {
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": process.env.GEMINI_API_KEY,
        },
      }
    );

    const aiText = res.data?.candidates?.[0]?.content?.parts?.[0]?.text || "(javob yo‘q)";
    console.log(chalk.redBright(`AI: ${aiText}\n`));
  } catch (err) {
    console.error(chalk.bgRed("Xatolik:"), err.response?.data || err.message);
  }

  rl.prompt();
});
