
```markdown
# 🧠 WormGPT — AI Chat in Your Terminal (Node.js)

**WormGPT** is a terminal-based AI chat built with **Node.js**.  
It brings the power of AI directly into your command line — fast, minimal, and clever.

> *"Words become code, thoughts turn into algorithms — WormGPT is your digital companion."*

---

## 🚀 Overview

- 💬 Real-time AI conversations in the terminal  
- ⚙️ Lightweight and simple configuration via `.env`  
- 🔐 Secure OpenAI API integration  
- 🧩 Fully extensible (chat logs, voice input, Telegram bot, etc.)

---



---

## ⚙️ Requirements

- Node.js v18+  
- An **AI API key** (or compatible AI API)

---

## 🧩 Installation

1️⃣ **Clone the repository**
```bash
git clone  https://github.com/muzaffarbekmustafayevgit/WormGPT.git
cd AI Chat
````

2️⃣ **Install dependencies**

```bash
npm init -y
npm install openai readline dotenv
```

3️⃣ **Create an `.env` file** in the project root:

```env
OPENAI_API_KEY=YOUR_API_KEY_HERE
```

> Replace `YOUR_API_KEY_HERE` with your actual OpenAI API key.
> You can get one from: [https://aistudio.google.com/api-keys]

---

## 💻 Example `index.js`

```js
import readline from "readline";
import OpenAI from "openai";
import dotenv from "dotenv";
dotenv.config();

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "WormGPT > ",
});

console.log("🤖 Welcome to WormGPT — your AI terminal assistant!");
console.log("Type `exit` anytime to quit.\n");
rl.prompt();

rl.on("line", async (input) => {
  const text = input.trim();
  if (!text) {
    rl.prompt();
    return;
  }

  if (text.toLowerCase() === "exit") {
    console.log("👋 Goodbye! WormGPT session ended.");
    rl.close();
    return;
  }

  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are WormGPT, a witty, concise, and helpful AI assistant." },
        { role: "user", content: text },
      ],
      max_tokens: 800,
    });

    const answer = response.choices?.[0]?.message?.content ?? "No response received.";
    console.log(`\n🧠 WormGPT: ${answer}\n`);
  } catch (err) {
    console.error("\n❗ Error:", err?.message ?? err);
  }

  rl.prompt();
});
```

---

## ▶️ Run the App

```bash
node index.js
```

Then type:

```
WormGPT > Hello, who are you?
🧠 WormGPT: I'm WormGPT — your terminal AI, here to make code and conversations flow. 😎
```

Exit the chat:

```
WormGPT > exit
👋 Goodbye! WormGPT session ended.
```

---

## ⚡ Customizing the Model

Change the model in `index.js` to use different AI engines:

```js
model: "gpt-4o-mini"
```

Examples:

* `gpt-4o-mini` — lightweight, fast
* `gpt-4o` — stronger and more capable
* `gpt-3.5-turbo` — efficient classic model

---

## 💡 Ideas for Expansion

| Feature                 | Description                                       |
| ----------------------- | ------------------------------------------------- |
| 🗂 Chat history         | Save all conversations to a local file            |
| 🎤 Voice input          | Add speech-to-text support (using Whisper API)    |
| 🤖 Telegram/Discord bot | Connect WormGPT to your favorite chat app         |
| 🌐 Web UI               | Create a React or Next.js interface               |
| 🧱 Local AI model       | Integrate `ollama` or `llama.cpp` for offline use |

---

## 🔐 Security Notes

* Never share or commit your `.env` file or API key.
* Use responsibly — WormGPT is for learning and personal use only.
* If you log user inputs, always respect privacy and data safety.

---

## 👨‍💻 Author

**Mustafayev Muzaffarbek**
Software Engineer — Samarkand State University
📍 Samarkand, Uzbekistan
📧 [muzaffarbekmustafayev@gmail.com](mailto:muzaffarbekmustafayev@gmail.com)

---

## 📜 License

```
MIT License  
Copyright (c) 2025 Mustafayev Muzaffarbek
Permission is hereby granted, free of charge, to any person obtaining a copy of this software...
```

---

## 🌟 Support

If you enjoy **WormGPT**, please ⭐ star the project on GitHub —
your support keeps ideas alive and the code evolving.

---

> 🪄 *"In every line of code hides a spark of thought — WormGPT is the whisper between logic and poetry."*

```
# WormGPT
# WormGPT
