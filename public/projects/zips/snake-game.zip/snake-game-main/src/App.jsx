import { useEffect, useState } from "react";

const GRID_SIZE = 20;
const BASE_SPEED = 180;
const MIN_SPEED = 80;
const INITIAL_DIRECTION = "right";
const INITIAL_SNAKE = [
  { x: 9, y: 10 },
  { x: 8, y: 10 },
  { x: 7, y: 10 },
];

const DIRECTION_VECTORS = {
  up: { x: 0, y: -1 },
  down: { x: 0, y: 1 },
  left: { x: -1, y: 0 },
  right: { x: 1, y: 0 },
};

const OPPOSITE_DIRECTIONS = {
  up: "down",
  down: "up",
  left: "right",
  right: "left",
};

const CELLS = Array.from({ length: GRID_SIZE * GRID_SIZE }, (_, index) => {
  const x = index % GRID_SIZE;
  const y = Math.floor(index / GRID_SIZE);
  return { x, y, key: `${x}-${y}` };
});

function createFood(snake) {
  const occupied = new Set(snake.map((segment) => `${segment.x}-${segment.y}`));
  const emptyCells = CELLS.filter((cell) => !occupied.has(cell.key));

  if (emptyCells.length === 0) {
    return null;
  }

  return emptyCells[Math.floor(Math.random() * emptyCells.length)];
}

function createInitialGame() {
  const snake = INITIAL_SNAKE.map((segment) => ({ ...segment }));

  return {
    snake,
    direction: INITIAL_DIRECTION,
    food: createFood(snake),
    score: 0,
    status: "running",
  };
}

function getStatusLabel(status) {
  if (status === "running") {
    return "Live";
  }

  if (status === "paused") {
    return "Paused";
  }

  if (status === "won") {
    return "Cleared";
  }

  return "Game Over";
}

function getStatusTone(status) {
  if (status === "running") {
    return "bg-emerald-100 text-emerald-900";
  }

  if (status === "paused") {
    return "bg-amber-100 text-amber-900";
  }

  if (status === "won") {
    return "bg-cyan-100 text-cyan-900";
  }

  return "bg-rose-100 text-rose-900";
}

export default function App() {
  const [game, setGame] = useState(() => createInitialGame());

  const speed = Math.max(MIN_SPEED, BASE_SPEED - game.score * 6);
  const snakeMap = new Map();

  game.snake.forEach((segment, index) => {
    snakeMap.set(`${segment.x}-${segment.y}`, index);
  });

  function restartGame() {
    setGame(createInitialGame());
  }

  function requestDirection(nextDirection) {
    setGame((current) => {
      if (current.status === "gameover" || current.status === "won") {
        return current;
      }

      if (OPPOSITE_DIRECTIONS[current.direction] === nextDirection) {
        return current;
      }

      return {
        ...current,
        direction: nextDirection,
      };
    });
  }

  function togglePause() {
    setGame((current) => {
      if (current.status === "gameover" || current.status === "won") {
        return current;
      }

      return {
        ...current,
        status: current.status === "running" ? "paused" : "running",
      };
    });
  }

  useEffect(() => {
    const onKeyDown = (event) => {
      const key = event.key.toLowerCase();

      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "enter", "w", "a", "s", "d", "r"].includes(key)) {
        event.preventDefault();
      }

      if (key === "arrowup" || key === "w") {
        requestDirection("up");
      } else if (key === "arrowdown" || key === "s") {
        requestDirection("down");
      } else if (key === "arrowleft" || key === "a") {
        requestDirection("left");
      } else if (key === "arrowright" || key === "d") {
        requestDirection("right");
      } else if (key === " ") {
        togglePause();
      } else if (key === "r" || key === "enter") {
        restartGame();
      }
    };

    window.addEventListener("keydown", onKeyDown);

    return () => {
      window.removeEventListener("keydown", onKeyDown);
    };
  }, []);

  useEffect(() => {
    if (game.status !== "running") {
      return undefined;
    }

    const intervalId = window.setInterval(() => {
      setGame((current) => {
        if (current.status !== "running") {
          return current;
        }

        const movement = DIRECTION_VECTORS[current.direction];
        const head = current.snake[0];
        const nextHead = {
          x: head.x + movement.x,
          y: head.y + movement.y,
        };

        const hitWall =
          nextHead.x < 0 ||
          nextHead.x >= GRID_SIZE ||
          nextHead.y < 0 ||
          nextHead.y >= GRID_SIZE;

        const willEatFood =
          current.food &&
          current.food.x === nextHead.x &&
          current.food.y === nextHead.y;

        const collisionBody = willEatFood ? current.snake : current.snake.slice(0, -1);
        const hitSelf = collisionBody.some(
          (segment) => segment.x === nextHead.x && segment.y === nextHead.y
        );

        if (hitWall || hitSelf) {
          return {
            ...current,
            status: "gameover",
          };
        }

        const nextSnake = [nextHead, ...current.snake];

        if (!willEatFood) {
          nextSnake.pop();
          return {
            ...current,
            snake: nextSnake,
          };
        }

        const nextFood = createFood(nextSnake);

        return {
          ...current,
          snake: nextSnake,
          food: nextFood,
          score: current.score + 1,
          status: nextFood ? "running" : "won",
        };
      });
    }, speed);

    return () => {
      window.clearInterval(intervalId);
    };
  }, [game.status, speed]);

  const statusLabel = getStatusLabel(game.status);
  const pauseButtonLabel = game.status === "running" ? "Pause" : "Resume";
  const pauseDisabled = game.status === "gameover" || game.status === "won";

  return (
    <main className="min-h-screen px-4 py-6 sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-6 lg:grid-cols-[minmax(0,1.25fr)_minmax(320px,0.75fr)]">
        <section className="board-enter overflow-hidden rounded-[2rem] border border-white/70 bg-white/80 p-4 shadow-panel backdrop-blur sm:p-6">
          <div className="mb-5 flex flex-col gap-4 border-b border-slate-200/80 pb-5 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.3em] text-tide">Prompt.md to Snake Game</p>
              <h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-5xl">Snake Reactor</h1>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-600 sm:text-base">
                20 x 20 grid, boshlang&apos;ich uzunlik 3, doimiy harakat, ovqat yeyish, score va collision
                tekshiruvlari `prompt.md` dagi qoida asosida yozildi.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-slate-500">Score</p>
                <p className="mt-1 text-3xl font-bold">{game.score}</p>
              </div>
              <div className={`rounded-full px-4 py-2 text-sm font-semibold ${getStatusTone(game.status)}`}>
                {statusLabel}
              </div>
            </div>
          </div>

          <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_260px]">
            <div className="space-y-4">
              <div className="rounded-[1.75rem] border border-slate-200 bg-slate-950 p-3 shadow-2xl shadow-slate-900/20 sm:p-4">
                <div
                  className="relative grid aspect-square w-full overflow-hidden rounded-[1.25rem] bg-slate-900 p-2 sm:p-3"
                  style={{
                    gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
                    gridTemplateRows: `repeat(${GRID_SIZE}, minmax(0, 1fr))`,
                    gap: "3px",
                  }}
                >
                  {CELLS.map((cell) => {
                    const segmentIndex = snakeMap.get(cell.key);
                    const isHead = segmentIndex === 0;
                    const isBody = segmentIndex !== undefined && segmentIndex > 0;
                    const isFood = game.food && game.food.x === cell.x && game.food.y === cell.y;

                    let className =
                      "rounded-[0.42rem] border border-white/5 bg-slate-800/70 transition-all duration-150";

                    if (isHead) {
                      className =
                        "rounded-[0.55rem] border border-mint/30 bg-gradient-to-br from-mint to-emerald-400 shadow-lg shadow-emerald-300/10";
                    } else if (isBody) {
                      className =
                        "rounded-[0.48rem] border border-emerald-700/10 bg-gradient-to-br from-emerald-400 to-tide";
                    } else if (isFood) {
                      className =
                        "food-glow rounded-full border border-orange-200/30 bg-gradient-to-br from-amber-300 via-orange-400 to-rose-500";
                    }

                    return <div key={cell.key} className={className} />;
                  })}

                  {(game.status === "gameover" || game.status === "won") && (
                    <div className="absolute inset-0 flex items-center justify-center rounded-[1.25rem] bg-slate-950/72 p-6 text-center">
                      <div>
                        <p className="font-mono text-xs uppercase tracking-[0.25em] text-orange-300">
                          {game.status === "won" ? "Full Clear" : "Collision"}
                        </p>
                        <h2 className="mt-3 text-3xl font-bold text-white">
                          {game.status === "won" ? "You cleared the board" : "Game Over"}
                        </h2>
                        <p className="mt-3 text-sm text-slate-300">
                          `Qayta o&apos;ynash` tugmasi, `R` yoki `Enter` bilan qayta boshlang.
                        </p>
                        <button
                          type="button"
                          onClick={restartGame}
                          className="mt-5 rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-orange-100"
                        >
                          Qayta o&apos;ynash
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-3">
                <button
                  type="button"
                  onClick={restartGame}
                  className="rounded-2xl bg-ink px-4 py-3 text-sm font-semibold text-white transition hover:bg-slate-800"
                >
                  Qayta boshlash
                </button>
                <button
                  type="button"
                  onClick={togglePause}
                  disabled={pauseDisabled}
                  className="rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-700 transition hover:border-slate-400 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {pauseButtonLabel}
                </button>
                <div className="rounded-2xl border border-orange-200 bg-orange-50 px-4 py-3 text-sm text-orange-950">
                  Speed: <span className="font-semibold">{speed}ms</span>
                </div>
              </div>
            </div>

            <aside className="space-y-4">
              <div className="rounded-[1.5rem] border border-slate-200 bg-slate-50 p-5">
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-slate-500">Rules</p>
                <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-700">
                  <li>Har yurishda ilonning boshi yangi katakka o&apos;tadi.</li>
                  <li>Odatdagi yurishda oxirgi segment o&apos;chadi.</li>
                  <li>Oziq yeganda uzunlik 1 taga va score 1 taga oshadi.</li>
                  <li>Ilon 180 daraja burila olmaydi.</li>
                  <li>Devor yoki tana bilan to&apos;qnashuv o&apos;yinni tugatadi.</li>
                </ul>
              </div>

              <div className="rounded-[1.5rem] bg-orange-400/95 p-5 text-slate-950">
                <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-slate-900/70">Controls</p>
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <div />
                  <button
                    type="button"
                    onClick={() => requestDirection("up")}
                    className="rounded-2xl bg-white/85 px-3 py-3 text-sm font-semibold shadow-sm transition hover:bg-white"
                  >
                    &uarr;
                  </button>
                  <div />
                  <button
                    type="button"
                    onClick={() => requestDirection("left")}
                    className="rounded-2xl bg-white/85 px-3 py-3 text-sm font-semibold shadow-sm transition hover:bg-white"
                  >
                    &larr;
                  </button>
                  <button
                    type="button"
                    onClick={() => requestDirection("down")}
                    className="rounded-2xl bg-white/85 px-3 py-3 text-sm font-semibold shadow-sm transition hover:bg-white"
                  >
                    &darr;
                  </button>
                  <button
                    type="button"
                    onClick={() => requestDirection("right")}
                    className="rounded-2xl bg-white/85 px-3 py-3 text-sm font-semibold shadow-sm transition hover:bg-white"
                  >
                    &rarr;
                  </button>
                </div>
                <p className="mt-4 text-sm leading-6 text-slate-900/80">
                  Keyboard: Arrow keys yoki WASD. Space bilan pause, `R` yoki `Enter` bilan qayta boshlash.
                </p>
              </div>

             
            </aside>
          </div>
        </section>

        <section className="board-enter rounded-[2rem] border border-white/70 bg-slate-950 p-6 text-white shadow-panel">
          <p className="font-mono text-xs uppercase tracking-[0.3em] text-orange-300">System Notes</p>
          <h2 className="mt-3 text-2xl font-bold">snake-game</h2>
          <p className="mt-4 text-sm leading-7 text-slate-300">
            Loyiha Vite asosida yozildi, React rendering ishlatiladi, Tailwind esa CDN orqali ulanadi. Shu bilan
            `prompt.md` dagi real-time harakat, koordinata va event handling talablari bitta sahifada jamlandi.
          </p>

          <div className="mt-6 space-y-4">
            <div className="rounded-[1.5rem] border border-white/10 bg-white/5 p-4">
              <p className="text-sm font-semibold text-white">Core config</p>
              <div className="mt-3 grid grid-cols-2 gap-3 text-sm text-slate-300">
                <div className="rounded-xl bg-white/5 p-3">Grid: 20 x 20</div>
                <div className="rounded-xl bg-white/5 p-3">Start length: 3</div>
                <div className="rounded-xl bg-white/5 p-3">Tick: 180ms</div>
                <div className="rounded-xl bg-white/5 p-3">Min tick: 80ms</div>
              </div>
            </div>

            <div className="rounded-[1.5rem] border border-white/10 bg-white/5 p-4">
              <p className="text-sm font-semibold text-white">States</p>
              <div className="mt-3 flex flex-wrap gap-2 text-sm">
                <span className="rounded-full bg-emerald-500/15 px-3 py-1 text-emerald-200">running</span>
                <span className="rounded-full bg-amber-500/15 px-3 py-1 text-amber-100">paused</span>
                <span className="rounded-full bg-rose-500/15 px-3 py-1 text-rose-200">gameover</span>
                <span className="rounded-full bg-cyan-500/15 px-3 py-1 text-cyan-200">won</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
