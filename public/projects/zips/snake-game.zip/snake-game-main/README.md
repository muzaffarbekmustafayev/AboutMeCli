# Snake Game

A simple Snake game built with React and Vite. The game follows the rules described in `prompt.md`: a 20x20 board, continuous movement, random food spawning, score tracking, speed increase after eating food, wall collision detection, and self-collision detection.

## Project Demo

![Snake Game Demo](./project-demo.png)

## Live Preview

[Open the live demo](https://snake-game-ten-umber.vercel.app)

## Features

- 20x20 game grid
- Snake starts with 3 segments
- Random food generation
- Score increases by 1 for each food eaten
- Game speed increases as the score grows
- Wall collision and self-collision detection
- Keyboard controls with arrow keys or `W`, `A`, `S`, `D`
- Pause, restart, and replay support
- Mobile-friendly on-screen direction controls

## Tech Stack

- React
- Vite
- Tailwind CSS via CDN

## Getting Started

### Prerequisites

- Node.js 18+ recommended
- npm

### Install dependencies

```bash
npm install
```

### Start the development server

```bash
npm run dev
```

### Build for production

```bash
npm run build
```

### Preview the production build

```bash
npm run preview
```

## Controls

- `Arrow Up` / `W`: move up
- `Arrow Down` / `S`: move down
- `Arrow Left` / `A`: move left
- `Arrow Right` / `D`: move right
- `Space`: pause or resume
- `R`: restart the game
- `Enter`: restart the game

## Project Structure

```text
snake-game/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── App.jsx
    ├── main.jsx
    └── styles.css
```

## Notes

- Tailwind CSS is loaded from the CDN in `index.html`.
- `node_modules` and `dist` are ignored through `.gitignore`, so the project is ready to push to GitHub.
- `package-lock.json` is kept in the repository for reproducible installs.
